'use strict'
import React, { Component } from "react";

export default class Header extends Component {
  render() {
    return (
      <div className = "header">
        <div className = "banner">
          <img src="images/u2.png"/>
        </div>
        <div className = "configuration-nav">
          <div className = "website-tab">
            <img src="images/u376.png" />
          </div>
          <div className = "facebook-tab">
            <img className="icon" src="images/u367.png" />
            <span>Facebook</span>
          </div>
          <div className = "twitter-tab">
            <img className="icon" src="images/u45.png" />
            <span>Twitter</span>
          </div>
        </div>
      </div>
    );
  }
}
