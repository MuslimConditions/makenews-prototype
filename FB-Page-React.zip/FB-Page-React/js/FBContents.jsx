'use strict';
import React, { Component } from "react";
import Sidebar from "./Sidebar";
import URLComponent from "./URLComponent";

export default class FBContents extends Component {
  constructor() {
    super();
    this.addUrl = this.addUrl.bind(this);
    this.removeUrl = this.removeUrl.bind(this);
    this.state = {
      "friends": [
        { "name": "Anurag Shinde", "url": "http://facebook.com/anuragshinde/profile"},
        { "name": "Barkha Datt", "url": "http://facebook.com/barkhadatt/profile"},
        { "name": "Aditi Nigam", "url": "http://facebook.com/aditinigam/profile"},
        { "name": "Chandan Rao", "url": "http://facebook.com/chandanrao/profile"},
        { "name": "Leena Nanda", "url": "http://facebook.com/leenananda/profile"},
        { "name": "Jyoti Kulkarni", "url": "http://facebook.com/jyotikulkarni/profile"},
        { "name": "Meena Bora", "url": "http://facebook.com/meenabora/profile"},
        { "name": "Keval Mutthal", "url": "http://facebook.com/kevalmutthal/profile"},
        { "name": "Parth Sharma", "url": "http://facebook.com/parthsharma/profile"},
        { "name": "Rahul Rathod", "url": "http://facebook.com/rahulrathod/profile"},
        { "name": "Pallavi Mishra", "url": "http://facebook.com/pallavimishra/profile"},
        { "name": "Shantanu Sagale", "url": "http://facebook.com/shantanusagale/profile"},
        { "name": "Jay Inamdar", "url": "http://facebook.com/jayinamdar/profile"},
        { "name": "Kush Moryani", "url": "http://facebook.com/kushmoryani/profile"},
        { "name": "Nikita Oswal", "url": "http://facebook.com/nikitaoswal/profile"},
        { "name": "Priyanka Khan", "url": "http://facebook.com/priyankakhan/profile"},
        { "name": "Manali Chopra", "url": "http://facebook.com/manalichopra/profile"},
        { "name": "Raj Shelar", "url": "http://facebook.com/rajshelar/profile"},
        { "name": "Monty Singh", "url": "http://facebook.com/montysingh/profile"},
        { "name": "Parul Patel", "url": "http://facebook.com/parulpatel/profile"},
        { "name": "Arun Dhingra", "url": "http://facebook.com/arundhingra/profile"}
      ],
      "groups":[
        {"name":"Journalist India", "url": "http://facebook.com/journalistindia/group"},
        {"name":"Voice of Journalist", "url": "http://facebook.com/voiceofjournalist/group"},
        {"name":"TV Journalist Association", "url": "http://facebook.com/tvjournalistassociation/group"},
        {"name":"Sherlock", "url": "http://facebook.com/sherlock/group"},
        {"name":"Health News", "url": "http://facebook.com/healthnews/group"},
        {"name":"Science and Philosophy", "url": "http://facebook.com/scienceandphilosophy/group"},
        {"name":"NID in Media", "url": "http://facebook.com/nidinmedia/group"},
        {"name":"News 24-7", "url": "http://facebook.com/news24-7/group"},
        {"name":"Biotech United", "url": "http://facebook.com/biotechunited/group"},
        {"name":"India Online", "url": "http://facebook.com/indiaonline/group"},
        {"name":"Politics and News", "url": "http://facebook.com/politicsandnews/group"},
        {"name":"BBC Volunteer Group", "url": "http://facebook.com/bbcvolunteergroup/group"},
        {"name":"TOI News", "url": "http://facebook.com/toinews/group"},
        {"name":"India News Daily", "url": "http://facebook.com/indianewsdaily/group"},
        {"name":"News Collection", "url": "http://facebook.com/newscollection/group"},
        {"name":"Indian Railways News Center", "url": "http://facebook.com/indiarailwaynews/group"},
        {"name":"Mumbai Times", "url": "http://facebook.com/mumbaitimes/group"},
        {"name":"Daily News", "url": "http://facebook.com/dailynews/group"}
      ],
      "pages":[
        {"name":"Deccan News", "url": "https://www.facebook.com/deccannews"},
        {"name":"DNA India", "url": "https://www.facebook.com/dnaindia"},
        {"name":"Economic Times", "url": "https://www.facebook.com/EconomicTimes/"},
        {"name":"Indian Express", "url": "https://www.facebook.com/indianexpress"},
        {"name":"NDTV", "url": "https://www.facebook.com/ndtv/"},
        {"name":"Scroll", "url": "https://www.facebook.com/scroll.in"},
        {"name":"The Guardian", "url": "https://www.facebook.com/theguardian/"},
        {"name":"The Hindu", "url": "https://www.facebook.com/thehindu"},
        {"name":"The Wire", "url": "https://www.facebook.com/TheWire"}
      ],
      "currentUrls": new Array(),
      "configuredUrls": {
        "friends": [],
        "groups": [],
        "pages": []
      }
    };

    this.state.currentUrls = this.state.friends;
    this.currentUrlTab = "friends";
  }

  changeUrlType(urlType, event) {
    this.setState({"currentUrls": this.state[urlType]});
    document.querySelectorAll(".fb-url-types .type").forEach((type) => {
      type.className = type.className.split(" current")[0];
    });
    event.target.className = `${urlType} type current`;
    this.currentUrlTab = urlType;
    document.getElementById("addAll").className = "";
    document.getElementById("removeAll").className = "hide";
  }

  addUrl(url, index) {
    let configuredUrls = this.state.configuredUrls;
    if (configuredUrls[this.currentUrlTab].indexOf(url) === -1) {
      configuredUrls[this.currentUrlTab].push(url);
      this.state[this.currentUrlTab][index]["status"] = "added";
      this.setState({"configuredUrls": configuredUrls});
    }
  }

  addAllUrls() {
    let configuredUrls = this.state.configuredUrls;
    configuredUrls[this.currentUrlTab] = this.state[this.currentUrlTab].map((url) => url.name);
    this.state[this.currentUrlTab] = this.state[this.currentUrlTab].map((url) => { url["status"] = "added"; return url});
    this.setState({"configuredUrls": configuredUrls});
    document.getElementById("addAll").className = "hide";
    document.getElementById("removeAll").className = "";
  }

  removeUrl(url) {
    let configuredUrls = this.state.configuredUrls;
    if (configuredUrls[this.currentUrlTab].indexOf(url) !== -1) {
      for(let i = 0; i<configuredUrls[this.currentUrlTab].length; i++) {
          if(configuredUrls[this.currentUrlTab][i] === url) {
              configuredUrls[this.currentUrlTab].splice(i, 1);
              break;
          }
      }

      for (let i=0; i<this.state[this.currentUrlTab].length; i++) {
        if(this.state[this.currentUrlTab][i].name === url) {
          this.state[this.currentUrlTab][i]["status"] = "";
          break;
        }
      }
      this.setState({"configuredUrls": configuredUrls});
    }
  }

  removeAllUrls(event) {
    let configuredUrls = this.state.configuredUrls;
    configuredUrls[this.currentUrlTab] = [];
    this.state[this.currentUrlTab] = this.state[this.currentUrlTab].map((url) => { url["status"] = ""; return url});
    this.setState({"configuredUrls": configuredUrls});
    document.getElementById("removeAll").className = "hide";
    document.getElementById("addAll").className = "";
  }

  render() {
    let urls = this.state.currentUrls.map((url, index) => <URLComponent key={index} index={index} { ...url } addUrlHandler={ this.addUrl }/>);
    return (
      <div className="fb-configuration">
        <div className="fb-configured-list"><Sidebar { ...this.state.configuredUrls } removeUrlHandler= { this.removeUrl }/></div>
        <div className="fb-right-body">
          <div className="searchbar">
            <input type="text" placeholder="Search friends, groups or pages" />
            <img className="search-icon" src = "images/u295.png" />
          </div>
          <div className="fb-list">
            <div className="fb-url-types">
              <div className="friends type current" onClick= {(event) => this.changeUrlType("friends", event)}>Friends</div>
              <div className="groups type" onClick= {(event) => this.changeUrlType("groups", event)}>Groups</div>
              <div className="pages type" onClick= {(event) => this.changeUrlType("pages", event)}>Pages</div>
              <div id="addAll" onClick = {(event) => this.addAllUrls(event)}>
                <img src="./images/u62.png" />
                Add All
              </div>
              <div id="removeAll" className="hide" onClick = {(event) => this.removeAllUrls(event)}>
                <img src="./images/u62.png" />
                Remove All
              </div>
            </div>
            <div className="fb-urls">
              { urls }
            </div>
            <div className="next-link">
              <img src="./images/u290.png" />
              <br />
              <img className="next" src="./images/u292.png" />
            </div>
          </div>
        </div>
      </div>
    )
  }
}
