'use strict';
import React, { Component } from "react";
import Header from "./Header";
import FBContents from "./FBContents";

export default class FBPage extends Component{
  render() {
    return (<div>
      <Header />
      <FBContents />
    </div>);
  }
}
