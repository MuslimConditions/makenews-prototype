'use strict';
import React, { Component } from "react";

export default class URLComponent extends Component {
  render() {
    return (
      <div className="url-to-configure">
        <div className="name">
        {
          this.props.status !== "added" ?
            (<div className="icon add-url" onClick={() => this.props.addUrlHandler(this.props.name, this.props.index)}>
              <img src="./images/u62.png" />
            </div>)
          :(<div className="icon add-url-added"><img src="./images/u64.png" /></div>)
        }
          { this.props.name }
        </div>
        <div className="url">{ this.props.url }</div>
      </div>
    );
  }
}
