'use strict';
import React from "react";
import ReactDOM from "react-dom";
import FBPage from "./FBPage";

ReactDOM.render(<FBPage />,
	document.getElementById("container"));
