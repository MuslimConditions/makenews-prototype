'use strict';
import React, { Component } from "react";
import ConfiguredUrlList from "./ConfiguredUrlList";

export default class Sidebar extends Component {
  render() {
    return (
      <div>
        <h2>My Sources</h2>
        <ConfiguredUrlList name="Facebook Friends" list={this.props.friends} removeUrlHandler={ this.props.removeUrlHandler }></ConfiguredUrlList>
        <ConfiguredUrlList name="Facebook Groups" list={this.props.groups} removeUrlHandler={ this.props.removeUrlHandler }></ConfiguredUrlList>
        <ConfiguredUrlList name="Facebook Pages" list={this.props.pages} removeUrlHandler={ this.props.removeUrlHandler }></ConfiguredUrlList>
      </div>
    );
  }
}
