'use strict';
import React, { Component } from "react";

export default class ConfiguredUrlList extends Component {
  constructor() {
    super();
    this.state = {"showAccordian": false};
  }
  render() {
    return (
      <div>
        <div className="configured-url-heading" onClick={() => { this.setState({"showAccordian": !this.state.showAccordian}) }}>{ this.props.name } <img src="./images/u502.png" /></div>
        <div className={this.state.showAccordian ? "configured-urls": "hide"}>
          {this.props.list.map((url, index) =>
            <div key={index} className="configured-url">{ url }
              <span className="remove-url" onClick={() => this.props.removeUrlHandler(url) }>x</span>
            </div>
          )}
        </div>
      </div>
    )
  }
}
